<?php 
return [
    "more"=> "Толығырақ",
    'last_news' => 'Соңғы жаңалықтар',
]
?>