<?php 
return [
    "more"=> "Подробнее",
    'last_news' => 'Последние новости',
]
?>